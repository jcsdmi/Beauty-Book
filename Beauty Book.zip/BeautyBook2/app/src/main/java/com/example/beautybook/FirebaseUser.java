package com.example.beautybook;

class FirebaseUser {
}
